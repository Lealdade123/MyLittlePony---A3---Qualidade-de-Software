# 4. Análise de Riscos — Rest Spring Test

## 4.1 Método

Os riscos foram identificados a partir da finalidade da API, das tecnologias e da estrutura de código observada. A classificação utiliza Probabilidade (P) e Impacto (I) em escala de 1 a 3: 1 = baixo, 2 = médio, 3 = alto. O nível é calculado por P × I: 1–2 baixo, 3–4 médio e 6–9 alto. As classificações são avaliações preliminares do grupo e devem ser revistas após a execução dos testes.

## 4.2 Registro de riscos

| ID | Risco | P | I | Nível | Consequência possível | Mitigação / resposta | Evidência ou teste relacionado |
|---|---|---:|---:|---|---|---|---|
| R-01 | Dados obrigatórios ou e-mail inválido serem aceitos | 2 | 3 | Alto (6) | Cadastro inconsistente e falhas posteriores | Executar testes negativos de Bean Validation e revisar respostas HTTP | CT-08, CT-09 |
| R-02 | Cadastro permitir e-mail duplicado em condições concorrentes | 2 | 3 | Alto (6) | Registros duplicados ou inconsistência | Testar repetição e concorrência; avaliar restrição única no banco. A existência de restrição única deve ser confirmada no schema | CT-10 e teste complementar concorrente |
| R-03 | Operações com ID inexistente não retornarem erro adequado | 2 | 3 | Alto (6) | Cliente receber resposta incorreta ou não padronizada | Testar consulta, atualização e exclusão com IDs inexistentes | CT-02, CT-04, CT-13, CT-15 |
| R-04 | Diferenças entre H2 e MySQL causarem comportamento divergente | 2 | 3 | Alto (6) | Testes passarem em H2 e falharem em ambiente MySQL | Executar integração com MySQL/TestContainers e comparar comportamentos | CT-17, CT-18 |
| R-05 | Ambiente sem Docker impedir testes que dependem de TestContainers | 2 | 2 | Médio (4) | Suíte de integração não iniciar | Documentar pré-requisito, validar Docker antes da execução e separar falha ambiental de falha funcional | CT-18; log de execução |
| R-06 | Cobertura de testes insuficiente em regras ou caminhos de erro | 2 | 3 | Alto (6) | Defeitos não detectados | Gerar relatório JaCoCo, identificar lacunas e criar testes direcionados | Relatório JaCoCo; CT-01 a CT-18 |
| R-07 | Defeitos de qualidade estática não identificados | 2 | 2 | Médio (4) | Manutenção mais difícil e possíveis erros | Executar SonarQube/SonarLint e avaliar bugs, vulnerabilidades e code smells | Relatório SonarQube |
| R-08 | Documentação OpenAPI não refletir o comportamento real | 2 | 2 | Médio (4) | Consumidores integrarem a API incorretamente | Conferir endpoints, parâmetros, exemplos e códigos de resposta no Swagger | CT-16 e comparação com Controller |
| R-09 | Erros de paginação ou ordenação afetarem listagens | 2 | 2 | Médio (4) | Dados apresentados de forma incompleta ou inesperada | Testar parâmetros de página, tamanho e ordenação, além dos padrões | CT-05, CT-06 e testes adicionais |
| R-10 | Configuração inadequada do perfil/banco gerar falha de inicialização ou conexão | 2 | 3 | Alto (6) | Aplicação indisponível no ambiente de execução | Revisar arquivos `application*.yml`, variáveis e credenciais sem expor segredos; testar cada perfil em ambiente controlado | Inicialização e CT-17/CT-18 |

## 4.3 Plano de acompanhamento

- Antes da execução: validar Java, Maven, perfil e Docker.
- Durante a execução: registrar logs, falhas, ambiente e commit analisado.
- Após os testes: recalcular a prioridade com base na frequência e gravidade dos defeitos observados.
- Antes da decisão de qualidade: confirmar que riscos altos possuem evidência, mitigação ou justificativa formal de aceite.

## 4.4 Limitações

Esta é uma análise preliminar baseada na leitura estática do material fornecido. Não foram realizados testes de carga, pentest, análise SonarQube ou execução integral da aplicação nesta etapa. Portanto, os riscos não representam defeitos confirmados; são eventos potenciais que precisam ser verificados.
