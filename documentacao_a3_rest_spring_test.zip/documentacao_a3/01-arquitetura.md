# 1. Documentação da Arquitetura — Rest Spring Test

## 1.1 Identificação

- **Projeto avaliado:** Rest Spring Test
- **Repositório de origem:** https://github.com/douglasfragoso/rest-spring-test
- **Tipo:** API REST para cadastro e gerenciamento de pessoas (`Person`)
- **Linguagem:** Java 21
- **Framework:** Spring Boot 3.3.3
- **Build e dependências:** Maven
- **Escopo desta análise:** código-fonte disponibilizado no arquivo ZIP recebido pelo grupo.

## 1.2 Objetivo e funcionalidades

A aplicação disponibiliza operações para consultar, cadastrar, atualizar e excluir registros de pessoas. Os dados da entidade são: identificador, nome, sobrenome, endereço, gênero e e-mail.

Endpoints identificados em `PersonController`:

| Método | Caminho | Finalidade | Resposta de sucesso indicada no código |
|---|---|---|---|
| GET | `/person/id/{id}` | Consultar pessoa por ID | 200 |
| GET | `/person/email/{email}` | Consultar pessoa por e-mail | 200 |
| GET | `/person` | Listar pessoas com paginação | 200 |
| POST | `/person` | Cadastrar pessoa | 201 |
| PUT | `/person` | Atualizar pessoa | 200 |
| DELETE | `/person/id/{id}` | Excluir pessoa por ID | 204 |

A listagem utiliza `Pageable`, com tamanho padrão 10, página inicial 0 e ordenação crescente por `id`.

## 1.3 Arquitetura lógica

O código está organizado em camadas:

1. **Controller (`PersonController`):** recebe requisições HTTP, aplica validação de entrada e constrói as respostas HTTP.
2. **Service (`PersonService`):** concentra as operações de negócio, como verificar existência de pessoa, impedir e-mail duplicado e executar atualização/exclusão.
3. **Repository (`PersonRepository`):** abstrai o acesso aos dados por meio do Spring Data JPA.
4. **Model (`Person`):** representa a entidade persistida na tabela `tb_person`.
5. **Tratamento de exceções (`Controller/Exception` e `Services/Exception`):** define respostas padronizadas para erros e exceções de negócio/banco.

Fluxo principal: Cliente HTTP → `PersonController` → `PersonService` → `PersonRepository` → Banco de dados. O resultado retorna pelo caminho inverso.

## 1.4 Modelo de dados e validações

A entidade `Person` está mapeada para a tabela `tb_person`. O campo `id` é gerado automaticamente. Os campos `firstName`, `lastName`, `address`, `gender` e `email` são obrigatórios nos grupos de validação de criação e atualização. O e-mail também recebe validação de formato (`@Email`). O identificador é obrigatório no grupo de atualização.

Limites declarados no mapeamento: nome e sobrenome com até 20 caracteres, endereço até 100, gênero até 10 e e-mail até 50. A análise não presume regras adicionais que não estejam expressas no código.

## 1.5 Tecnologias e configuração

| Tecnologia | Uso identificado |
|---|---|
| Java 21 | Linguagem da aplicação |
| Spring Boot 3.3.3 | Estrutura da aplicação |
| Spring Web | Endpoints REST |
| Spring Data JPA | Persistência relacional |
| Bean Validation | Validação dos dados de entrada |
| H2 | Banco em memória no perfil de teste/desenvolvimento descrito no README |
| MySQL | Banco relacional no perfil `prod` descrito no README |
| JUnit 5 e Mockito | Testes automatizados |
| Rest-Assured | Testes de API |
| TestContainers | Infraestrutura de banco em container para testes de integração |
| JaCoCo | Medição de cobertura de código |
| Maven Surefire | Execução/relatório de testes |
| Springdoc OpenAPI / Swagger UI | Documentação interativa da API |
| Lombok | Redução de código repetitivo |
| Postman | Coleção para chamadas manuais à API |

## 1.6 Estratégia de testes já presente no repositório

Foram identificadas classes de teste para Controller, Service, Repository, integração do Controller e Swagger, além de teste de inicialização. Há testes unitários com dependências simuladas e testes de integração com infraestrutura de banco baseada em TestContainers. A existência dos arquivos demonstra a implementação de testes, mas não comprova que todos passam no ambiente do grupo; isso deverá ser verificado pela execução e pelos relatórios.

## 1.7 Limites da análise

Esta documentação descreve a estrutura observada no ZIP. Não foi executada, nesta etapa, a aplicação, a suíte Maven, o SonarQube ou a geração de relatórios JaCoCo. Portanto, não são atribuídos índices de cobertura, qualidade estática ou aprovação dos testes. Esses resultados devem ser anexados como evidências na próxima etapa.

## 1.8 Referências técnicas internas

- `README.md`
- `rest-spring-test/pom.xml`
- `src/main/java/com/restspringtest/Controller/PersonController.java`
- `src/main/java/com/restspringtest/Services/PersonService.java`
- `src/main/java/com/restspringtest/Repository/PersonRepository.java`
- `src/main/java/com/restspringtest/Model/Person.java`
- `src/main/resources/application*.yml`
- `src/test/java/com/restspringtest/`
