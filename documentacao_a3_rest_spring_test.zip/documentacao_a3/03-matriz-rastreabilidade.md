# 3. Matriz de Rastreabilidade — Rest Spring Test

A matriz relaciona funcionalidades/requisitos observados no código com os casos de teste propostos. Os IDs CT correspondem ao Plano de Testes.

| ID requisito | Requisito / comportamento | Origem no código | Caso(s) relacionado(s) | Prioridade |
|---|---|---|---|---|
| RF-01 | Consultar pessoa por identificador | `PersonController.findById`; `PersonService.findById` | CT-01, CT-02 | Alta |
| RF-02 | Consultar pessoa por e-mail | `PersonController.findByEmail`; `PersonService.findByEmail` | CT-03, CT-04 | Alta |
| RF-03 | Listar pessoas de forma paginada | `PersonController.findAll`; `PersonService.findAll` | CT-05, CT-06 | Média |
| RF-04 | Cadastrar pessoa | `PersonController.save`; `PersonService.save` | CT-07, CT-08, CT-09, CT-10 | Alta |
| RF-05 | Impedir cadastro de e-mail já registrado | `PersonService.save` | CT-10 | Alta |
| RF-06 | Atualizar pessoa existente | `PersonController.update`; `PersonService.update` | CT-11, CT-12, CT-13 | Alta |
| RF-07 | Excluir pessoa por identificador | `PersonController.deleteById`; `PersonService.deleteById` | CT-14, CT-15 | Alta |
| RNF-01 | Validar campos obrigatórios e formato de e-mail | `Model/Person.java` e validação no Controller | CT-08, CT-09, CT-12 | Alta |
| RNF-02 | Persistir dados usando JPA e banco configurado | `PersonRepository`; configurações `application*.yml` | CT-17, CT-18 | Alta |
| RNF-03 | Disponibilizar documentação da API | Dependências Springdoc e anotações OpenAPI no Controller | CT-16 | Média |
| RNF-04 | Manter testes automatizados executáveis | `src/test/java` e configuração Maven | Execução geral da suíte; evidência no Surefire | Alta |
| RNF-05 | Medir cobertura dos testes | Plugin JaCoCo em `pom.xml` | Relatório JaCoCo a coletar | Média |

## Observações de rastreabilidade

1. Os requisitos acima foram derivados das rotas, regras e configurações encontradas no código e no README.
2. Os casos CT são planejados; a matriz não indica que foram executados ou aprovados.
3. Para fechar a rastreabilidade, após a execução, acrescentar as colunas **Resultado**, **Evidência/arquivo**, **Defeito associado** e **Responsável**.
4. Requisitos de segurança, desempenho, disponibilidade e acessibilidade não foram incluídos como requisitos implementados, pois não há evidência suficiente no material analisado. Podem ser propostos como avaliação complementar, identificados claramente como requisitos não funcionais adicionais do grupo.
