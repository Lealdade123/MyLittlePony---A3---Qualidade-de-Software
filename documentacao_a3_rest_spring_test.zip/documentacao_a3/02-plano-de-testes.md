# 2. Plano de Testes — Rest Spring Test

## 2.1 Objetivo

Definir a abordagem para avaliar a qualidade funcional e técnica da API Rest Spring Test, verificando as operações de gerenciamento de pessoas, validações, tratamento de erros, persistência e documentação da API.

## 2.2 Escopo

**Incluído:** consulta por ID e e-mail; listagem paginada; criação; atualização; exclusão; validação de campos; e-mail duplicado; registros inexistentes; integração com banco; inicialização da aplicação; documentação Swagger.

**Fora do escopo nesta etapa:** interface gráfica (não identificada no projeto), testes de carga/performance, segurança/autenticação (não identificadas no código analisado), testes em produção e avaliação de infraestrutura externa.

## 2.3 Abordagem e níveis

- **Testes unitários:** avaliar regras isoladas de Service e comportamento de Controller/Repository conforme as classes existentes. Mockito pode isolar dependências.
- **Testes de integração:** validar a interação entre API, camada de persistência e banco configurado para testes, utilizando TestContainers conforme os testes existentes.
- **Testes de API:** enviar requisições HTTP e conferir status, conteúdo e comportamento dos endpoints, com Rest-Assured e/ou Postman.
- **Testes de documentação:** verificar a disponibilidade da interface Swagger/OpenAPI e sua coerência com os endpoints.
- **Análise estática e cobertura:** executar SonarQube/SonarLint e JaCoCo na etapa de avaliação de qualidade; registrar os resultados reais, sem estimá-los previamente.

## 2.4 Ambiente e ferramentas

- Java 21 e Maven, conforme `pom.xml`.
- Spring Boot 3.3.3.
- Perfil de teste com H2 conforme README e arquivos de configuração.
- TestContainers/MySQL para testes de integração configurados no projeto; requer Docker disponível.
- JUnit 5, Mockito, Rest-Assured, Postman e JaCoCo.
- SonarQube/SonarLint para análise estática na etapa de inspeção.

## 2.5 Condições de entrada

1. Código-fonte obtido e dependências Maven resolvidas.
2. Java 21 instalado e configurado.
3. Docker disponível quando forem executados os testes que usam TestContainers.
4. Configurações de banco e perfil de teste revisadas.
5. Repositório em estado conhecido, com registro do commit analisado.

## 2.6 Critérios de saída

- Todos os casos planejados executados ou justificados como não executáveis.
- Resultado (aprovado/reprovado/bloqueado) registrado para cada caso.
- Evidências armazenadas: logs, relatórios Surefire, relatório JaCoCo, capturas de requisições e relatório SonarQube.
- Defeitos registrados com passos para reprodução, resultado esperado e obtido.
- Riscos críticos avaliados e recomendação de qualidade fundamentada nas evidências.

## 2.7 Casos de teste propostos

| ID | Cenário | Preparação/ação | Resultado esperado |
|---|---|---|---|
| CT-01 | Consultar pessoa existente por ID | Cadastrar pessoa e consultar `/person/id/{id}` | HTTP 200 e dados correspondentes |
| CT-02 | Consultar ID inexistente | Consultar ID não cadastrado | Erro de não encontrado conforme tratamento implementado |
| CT-03 | Consultar pessoa por e-mail existente | Cadastrar e consultar `/person/email/{email}` | HTTP 200 e pessoa correspondente |
| CT-04 | Consultar e-mail inexistente | Consultar e-mail não cadastrado | Erro de não encontrado conforme tratamento implementado |
| CT-05 | Listar pessoas | Chamar `GET /person` | HTTP 200 e estrutura paginada |
| CT-06 | Validar paginação e ordenação padrão | Chamar `GET /person` sem parâmetros | Página 0, tamanho 10 e ordenação crescente por ID |
| CT-07 | Cadastrar pessoa válida | Enviar POST com campos obrigatórios válidos | HTTP 201 e pessoa criada |
| CT-08 | Cadastrar sem campo obrigatório | Enviar POST omitindo ou deixando em branco um campo obrigatório | HTTP 400 com erro de validação |
| CT-09 | Cadastrar e-mail em formato inválido | Enviar POST com e-mail inválido | HTTP 400 com erro de validação |
| CT-10 | Cadastrar e-mail já existente | Cadastrar e repetir o mesmo e-mail | HTTP 400 conforme contrato documentado no Controller |
| CT-11 | Atualizar pessoa existente | Enviar PUT com ID válido e campos válidos | HTTP 200 e confirmação de atualização |
| CT-12 | Atualizar sem ID | Enviar PUT sem identificador | HTTP 400 por validação |
| CT-13 | Atualizar pessoa inexistente | Enviar PUT com ID não cadastrado | Erro de não encontrado |
| CT-14 | Excluir pessoa existente | Enviar DELETE para ID cadastrado | HTTP 204 |
| CT-15 | Excluir pessoa inexistente | Enviar DELETE para ID não cadastrado | Erro de não encontrado |
| CT-16 | Verificar documentação Swagger | Acessar `/swagger-ui/index.html` com aplicação ativa | Interface/documentação acessível |
| CT-17 | Verificar persistência no perfil de teste | Criar e consultar registro no perfil H2 | Registro disponível conforme configuração do teste |
| CT-18 | Verificar integração com MySQL em container | Executar testes de integração com Docker disponível | Integração executada sem falha ambiental e resultados registrados |

Observação: os casos CT-01 a CT-18 são uma proposta de avaliação do grupo. A presença de casos semelhantes no código não substitui a execução e o registro formal de evidências.

## 2.8 Priorização

- **Alta:** criação, validação, e-mail duplicado, consulta, atualização e exclusão; são as funções centrais da API.
- **Média:** paginação, integração com banco e Swagger.
- **Baixa:** aspectos complementares de apresentação de mensagens, desde que não afetem o contrato funcional.

## 2.9 Evidências a coletar

- Saída do comando `mvn clean test`.
- Relatório Surefire (quantidade de testes, falhas, erros e ignorados).
- Relatório HTML/XML do JaCoCo (cobertura por pacote/classe/método).
- Evidências de requisições Postman/Rest-Assured.
- Resultado da análise SonarQube, incluindo bugs, vulnerabilidades, code smells e duplicações.
- Identificação do commit, data, ambiente e responsável pela execução.
